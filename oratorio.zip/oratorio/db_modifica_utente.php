<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "oratorio";
    $id_delete = $_COOKIE["GetCookie"];
  
    if (isset($_POST))
    {
        $conn = new mysqli($servername, $username, $password, $dbname);
        if (mysqli_connect_errno()) 
        {
            printf("Connect failed: %s\n", mysqli_connect_error());
            exit();
        }
        

        $utf = mysqli_query($conn, "set character set utf8");
        $nome=mysqli_real_escape_string($conn,$_POST["nome"]);
        $cognome=mysqli_real_escape_string($conn,$_POST["cognome"]);
        $sesso=mysqli_real_escape_string($conn,$_POST["sesso"]);
        $luogo=mysqli_real_escape_string($conn,$_POST["luogo"]);
        $data=mysqli_real_escape_string($conn,$_POST["data"]);
        $indirizzo=mysqli_real_escape_string($conn,$_POST["indirizzo"]);
        $telefono=mysqli_real_escape_string($conn,$_POST["telefono"]);
        $ruolo=mysqli_real_escape_string($conn,$_POST["ruolo"]);
        $autorizzazione=mysqli_real_escape_string($conn,$_POST["autorizzazione"]);
        $soldi=mysqli_real_escape_string($conn,$_POST["soldi"]);
        //////////////////////////////////////////////
        $id_delete=mysqli_real_escape_string($conn,$id_delete); 
        $id_utente=$id_delete;
        $updates = mysqli_query($conn, "UPDATE utente SET id = '$id_delete', nome = '$nome', cognome = '$cognome', sesso = '$sesso', luogo_nascita='$luogo', data_nascita='$data', indirizzo='$indirizzo', telefono='$telefono', ruolo='$ruolo', autorizzazione='$autorizzazione', soldi='$soldi' where id='$id_delete'");
        if($delete2 = mysqli_query($conn, "DELETE FROM sceglie where id_utente='$id_delete'")===TRUE)
         {

             //SCELTA ATTIVITA, SE SI AGGIUNGE UNA NUOVA ATTIVITA ALLE 11 PROPOSTE, AGGIUNGERLA ANCHE QUI, CON IL RELATIVO NOME
            if (isset($_POST["Calcio"]))
            {
        
                
                $id=$_POST["Calcio"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");
                
                
            }
            if (isset($_POST["Pallavolo"]))
            {
                
                $id=$_POST["Pallavolo"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");
                
            }
            if (isset($_POST["Basket"]))
            {
                
                $id=$_POST["Basket"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");        
            }

            if (isset($_POST["Teatro"]))
            {
                
                $id=$_POST["Teatro"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')"); 
            }   
            
            if (isset($_POST["Canto"]))
            {
                
                $id=$_POST["Canto"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')"); 
            } 


            if (isset($_POST["Ballo"]))
            {
                
                $id=$_POST["Ballo"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");
            }
            if (isset($_POST["Musica"]))
            {
                
                $id=$_POST["Musica"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");
            }
            if (isset($_POST["PingPong"]))
            {
                
                $id=$_POST["PingPong"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");  
            }
            if (isset($_POST["Biliardino"]))
            {
                
                $id=$_POST["Biliardino"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");       
            }
            if (isset($_POST["Informatica"]))
            {
               
                $id=$_POST["Informatica"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");
            }

            if (isset($_POST["Lavoretti_artistici"]))
            {
                
                $id=$_POST["Lavoretti_artistici"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");    
            }
            if (isset($_POST["Doposcuola"]))
            {
                
                $id=$_POST["Doposcuola"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");    
            }
            if (isset($_POST["AC"]))
            {
               
                $id=$_POST["AC"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");    
            }
            if (isset($_POST["Catechismo"]))
            {
               
                $id=$_POST["Catechismo"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");    
            }

        
                //sleep(1);
               // header("location: lista_iscritti.php");
         }
       
        

       

        mysqli_close($conn);
    }

?>