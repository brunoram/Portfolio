<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Iscritti</title>
    
   <link rel="stylesheet" href="css/elenco_iscritti_attività.css"/> 
   <script src="js\elenco_iscritti_attività.js" defer="true"></script> 
   <link rel="stylesheet" href="css/button_home.css"/> 
  </head>

  

  <body>
  <?php 
 $servername="localhost";
 $username="root";
 $password="";
 $dbname="oratorio";

 $conn=new mysqli($servername, $username, $password, $dbname);
 if($conn->connect_error)
 {
      die ("Connection failed " .$conn->connect_error);
 }
 
 if(isset($_GET["id"]))
 {
    $id=$_GET["id"];
    //RICERCA ATTIVITA' SCELTE DALL'UTENTE;
    $utf = mysqli_query($conn, "set character set utf8");
    $check=mysqli_query($conn, "select u.nome, u.cognome, u.data_nascita, u.telefono FROM sceglie s join utente u where id_attivita='$id' and s.id_utente=u.id");
    $row_cnt = mysqli_num_rows($check);
    while($riga=mysqli_fetch_assoc($check))
     {
        $vector[]=$riga;
        
      }

mysqli_free_result($check);
mysqli_close($conn);
@$_GLOBALS["vett"]=$vector;   
@$_GLOBALS["count"]=$row_cnt;
 }
 ?>

  <header>

  <h1>ORATORIO "DON BOSCO"</h1>
  <h3>Parrocchia "B.M.V. dell'Angelo Annunziata" - Biancavilla</h3>
  <button id="btn" class="button_home" onclick="window.location.href = 'index.php';">Home</button>
  </header>


    <div id="grande">

    

</div>



<script> 
const js = <?php echo json_encode($_GLOBALS["vett"]); ?>;  
const count= <?php echo json_encode($_GLOBALS["count"]); ?>;

const count_line = document.createElement('p');
count_line.textContent="Iscritti a questa attività: "+count;
const butt=document.getElementById('btn');
butt.appendChild(count_line);

const first=document.createElement('div');
        first.classList.add("row");
        const first_info=document.createElement('div');
        first_info.classList.add("div_info");
       
        const frow=document.createElement('div');
        frow.classList.add("row");
        const f0=document.createElement('p');
        f0.textContent= "#";
        f0.classList.add("first");
        const f1=document.createElement('p');
        f1.textContent= "Nome";
        f1.classList.add("first");
        const f2=document.createElement('p');
        f2.textContent= "Cognome";
        f2.classList.add("first"); 
        const f3=document.createElement('p');
        f3.textContent= "Data di nascita";
        f3.classList.add("first"); 
        const f4=document.createElement('p');
        f4.textContent= "Telefono";
        f4.classList.add("first"); 
        
        const box=document.querySelector("#grande");
        box.appendChild(frow);
        frow.appendChild(first);
        first.appendChild(first_info);
        first_info.appendChild(f0);
        first_info.appendChild(f1);
        first_info.appendChild(f2);
        first_info.appendChild(f3);
        first_info.appendChild(f4);
for(x of js)
        {
           

        //div riga singolo elemento
        const id=1;
        const div_row=document.createElement('div');
        div_row.classList.add("row");
        //nome e cognome
        const div_info=document.createElement('div');
        div_info.classList.add("div_info");

        const id_space = document.createElement('p');
        id_space.textContent=id+".";

        const nome=document.createElement('p');
        nome.textContent= x.nome;
   
        const cognome=document.createElement('p');
        cognome.textContent= x.cognome;

        const date=document.createElement('p');
        date.textContent = x.data_nascita;

        const tel=document.createElement('p');
        tel.textContent = x.telefono;
        
        div_info.appendChild(id_space);
        div_info.appendChild(nome);
        div_info.appendChild(cognome);
        div_info.appendChild(date);
        div_info.appendChild(tel);
        div_row.appendChild(div_info);
        
        
       
       
        box.appendChild(div_row);
        id=id+1;
        }
</script>

</body>
</html>