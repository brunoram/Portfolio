<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lista iscritti</title>
    <link rel="stylesheet" href="css/lista_iscritti.css"/>
    <script src="js/lista_iscritti.js" defer="true"></script>
    <!-- <link rel="stylesheet" href="style.css"/> -->
    <script src="DataTables/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
    <link rel="stylesheet" href="css/button_home.css"/> 
    

   
  </head>

  

  <body>
  
  <header>
      
      <div id="sx">
      <img src="css/img/logo.png" height="85%" width="37%">
  <button id="btn" class="button_home" onclick="window.location.href = 'index.php';">Home</button>
</div>
  <div id="dx">
      <h1>ORATORIO "DON BOSCO"</h1>
  <h3>Parrocchia "B.M.V. dell'Angelo Annunziata" - Biancavilla</h3>
</div>
  

  </header>


  <div id="tables">
    <p id="mod">Per modificare un utente, cliccare sul nome.</p>
  <table id="table" class="display">
      <thead id="the">
            <tr>
                <th id="id">ID</th>
                <th id="ruolo">Ruolo</th>
                <th id="nome">Nome</th>
                <th id="cognome">Cognome</th>
                <th id="sesso">Sesso</th>
                <th id="data">Data di nascita</th>
                <th id="luogo">Luogo di nascita</th>
                <th id="indirizzo">Indirizzo</th>
                <th id="telefono">Telefono</th>
                <th id="soldi">Soldi</th>
                <th id="autorizzazione">Da solo a casa?</th>
                <th id="attività">Attività scelte</th>
            </tr>
        </thead>

        <tbody>
        <?php

            $servername="localhost";
            $username="root";
            $password="";
            $dbname="oratorio";

            $vector= array();
            
            $conn=new mysqli($servername, $username, $password, $dbname);
            if($conn->connect_error)
            {
                die ("Connection failed " .$conn->connect_error);
            }

            $utf = mysqli_query($conn, "set character set utf8");

            $ris = mysqli_query($conn, "SELECT * from utente");
            $row_cnt = mysqli_num_rows($ris);
            @$_GLOBALS["tot"]=$row_cnt;
            while($riga=mysqli_fetch_assoc($ris))
                {
                   $id=$riga['id'];
                   $ruolo=$riga['ruolo'];
                   $nome=urlencode($riga['nome']);
                   $cognome=urlencode($riga['cognome']);
                   $sesso=$riga['sesso'];
                   $data=$riga['data_nascita'];
                   $luogo=urlencode($riga['luogo_nascita']);
                   $indirizzo=urlencode($riga['indirizzo']);
                   $telefono=urlencode($riga['telefono']);
                   $soldi=$riga['soldi'];
                   $autorizzazione=$riga['autorizzazione'];
                   $attività = mysqli_query($conn, "SELECT a.nome FROM sceglie s join attivita a where s.id_utente='$id' and s.id_attivita=a.id");          
                   $r=null;
                   $all=null;
                   while($r=mysqli_fetch_assoc($attività))
                   {
                      $all[]=$r;
                      
                    }
                   echo "<tr>";
                   echo "<td>".$riga['id']."</td>";
                   echo "<td>".$riga['ruolo']."</td>";
                   echo "<td><a href=modifica_utente.php?id=$id&ruolo=$ruolo&nome=$nome&cognome=$cognome&sesso=$sesso&data_nascita=$data&luogo_nascita=$luogo&indirizzo=$indirizzo&telefono=$telefono&soldi=$soldi&autorizzazione=$autorizzazione >".$riga['nome']."</td></a>";
                   echo "<td>".$riga['cognome']."</td>";
                   echo "<td>".$riga['sesso']."</td>";
                   echo "<td>".$riga['data_nascita']."</td>";
                   echo "<td>".$riga['luogo_nascita']."</td>";
                   echo "<td>".$riga['indirizzo']."</td>";
                   echo "<td>".$riga['telefono']."</td>";
                   echo "<td>".$riga['soldi']." </td>";
                   echo "<td>".$riga['autorizzazione']." </td> ";
                   echo "<td>";
                   
                  
                    foreach($all as $one)
                     {
                     echo($one['nome']." - ");
                     } 
                  
                   echo "</td>";
                   
                }
                mysqli_free_result($attività);
                mysqli_free_result($ris);
                mysqli_close($conn);
?>  

</tbody>
    </table>

    <script type="text/javascript" src="DataTables/datatables.min.js"></script>
    <script type= "text/javascript"> 
    $(document).ready( function () {
            $('#table').DataTable();
        } );
    
    </script>
    <script defer="true">
        const count= <?php echo json_encode($_GLOBALS["tot"]); ?>;

        const count_line = document.createElement('p');
        count_line.textContent="Numero totale iscritti: "+count;
        const butt=document.getElementById('btn');
        butt.appendChild(count_line);
    </script>
</div>

  </body>
</html>