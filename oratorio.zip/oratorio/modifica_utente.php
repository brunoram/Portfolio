<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Modifica utente</title>
   <!-- <link rel="stylesheet" href="css/modifica_utente.css"/>-->
    <link rel="stylesheet" href="css/button_home.css"/> 
    <link rel="stylesheet" href="css/crea_utente.css"/>
   <script src="js\modifica_utente.js" defer="true"></script>
   <!-- <script src="js\modifica_attivita.js" defer="true"></script> -->
  </head>

  

  <body>


  <?php 
 $servername="localhost";
 $username="root";
 $password="";
 $dbname="oratorio";

 $conn=new mysqli($servername, $username, $password, $dbname);
 if($conn->connect_error)
 {
      die ("Connection failed " .$conn->connect_error);
 }
 
 if(isset($_GET["id"]) && isset($_GET["ruolo"]))
 {
     $jn=($_GET["id"]);
    setcookie("GetCookie", $jn, time()+3600);
    
    $ruolo=$_GET["ruolo"];
    $id=$_GET["id"];
    //RICERCA ATTIVITA' SCELTE DALL'UTENTE;
    $utf = mysqli_query($conn, "set character set utf8");
    $check=mysqli_query($conn, "select id_attivita FROM sceglie where id_utente='$id'");
    
    while($riga=mysqli_fetch_assoc($check))
     {
        $vector[]=$riga;
        
      }

mysqli_free_result($check);
mysqli_close($conn);
@$_GLOBALS["vect"]=$vector;   
 }
 ?>
  <header>
      
      <div id="sx">
      <img src="css/img/logo.png" height="85%" width="37%">
  <button class="button_home" onclick="window.location.href = 'index.php';">Home</button>
</div>
  <div id="dx">
      <h1>ORATORIO "DON BOSCO"</h1>
  <h3>Parrocchia "B.M.V. dell'Angelo Annunziata" - Biancavilla</h3>
</div>
  

  </header>


  <section id="crea_utente">
            <h2 id="p-title">Modifica utente</h2>
                    <p>Per il ruolo si intende:<br>
                        animatore: 15-18 anni<br>
                        educatore: >18anni<br>
                        custode: uomini <br>
                        assistente: donne<br>
                        utente: un qualunque ragazzo iscritto senza alcuna responsabilità all'interno dell'oratorio
                    </p>
                    <div id="container">
            <form id="new_utente" autocomplete="off" method="POST" action="db_modifica_utente.php">
            <div id="ruolo">
            <strong>Ruolo:</strong><br>
                <input type="radio" id="Utente" name="ruolo" value="Utente"> <span class="bold">Utente normale</span><br>
                <input type="radio" id="Educatore" name="ruolo" value="Educatore"> Educatore adulto<br>
                <input type="radio" id="Animatore"  name="ruolo" value="Animatore"> Animatore<br>
                <input type="radio" id="Custode" name="ruolo" value="Custode"> Custode<br>
                <input type="radio" id="Assistente" name="ruolo" value="Assistente"> Assistente<br>
                <input type="radio" id="Insegnante" name="ruolo" value="Insegnante"> Insegnante dopo-scuola<br>
                </div>
          <script> 
            const ruolo = "<?php echo $_GET["ruolo"];?>";
            switch(ruolo)
            //FUNZIONE PER SELEZIONARE IL VECCHIO RUOLO DELL'UTENTE
            {
                case "Utente":
                    document.getElementById("Utente").checked = true;
                    break;
                case "Educatore":
                    document.getElementById("Educatore").checked = true;
                    break;
                case "Animatore":
                    document.getElementById("Animatore").checked = true;
                    break;
                case "Custode":
                    document.getElementById("Custode").checked = true;
                    break;
                case "Assistente":
                    document.getElementById("Assistente").checked = true;
                    break;
                case "Insegnante":
                    document.getElementById("Insegnante").checked = true;
                    break;

            }
           
          </script>
                <strong>Nome:</strong><br>
                <input type="text" class="form-field" id="nome" name="nome" value="<?php echo $_GET["nome"] ?>"><br>
                <strong>Cognome:</strong> <br>
                <input type="text" class="form-field" id="cognome" name="cognome" value="<?php echo $_GET["cognome"] ?>"><br>
                <strong>Sesso(m/f):</strong> <br>
            <input type="text" class="form-field" id="sesso" name="sesso" value="<?php echo $_GET["sesso"] ?>"><br>
            <strong>Luogo di nascita:</strong> <br>
                <input type="text" class="form-field" id="luogo"  name="luogo" value="<?php echo $_GET["luogo_nascita"] ?>"><br>
                <strong>Data di nascita(gg/mm/aaaa):</strong> <br>
                <input type="text" class="form-field" id="data" name="data" value="<?php echo $_GET["data_nascita"] ?>"><br>
                <strong>Indirizzo: </strong><br>
                <input type="text" class="form-field" id="indirizzo" name="indirizzo" value="<?php echo $_GET["indirizzo"] ?>"><br>
                <strong>Telefono: </strong><br>
                <input type="text" class="form-field" id="telefono" name="telefono" value="<?php echo $_GET["telefono"] ?>"><br>
                <strong>Può andare da solo a casa?(si/no):</strong> <br>
                <input type="text" class="form-field" id="autorizzazione" name="autorizzazione" value="<?php echo $_GET["autorizzazione"] ?>"><br>
                <strong>Soldi(si/no):</strong> <br>
                <input type="text" class="form-field" id="soldi" name="soldi" value="<?php echo $_GET["soldi"] ?>"><br>
            <span>Seleziona le attività a cui si vuole iscrivere l'utente:</span><br>
                <!-- Inserire checkbox attività dinamicamente -->
                <div id="before" class="control-group">
            </div>
                <input class="myButton" type="submit" name="submit" value="Salva">
        </form>
        </div>
                </section>
    

<script> 
  fetch("http://localhost/oratorio/checkbox_attività.php").then(onResponse).then(onJSON);

function onResponse(response){
  
  return response.json();
}

function onJSON(json){
    const form =document.querySelector("new_utente");
  for(let element of json)
  {
    const label = document.createElement('label');  //label attività
    label.classList.add("control", "control-checkbox");

    const nome = document.createElement('span'); //nome attività
    nome.innerText=element.nome;
    nome.id="act";

    label.appendChild(nome);

    const checkbox = document.createElement('input');
    checkbox.type = "checkbox";
    checkbox.name = element.nome;
    checkbox.value = element.id;
    checkbox.id = element.id;

    label.appendChild(checkbox);

    const div_inside = document.createElement('div');
    div_inside.classList.add("control_indicator");
    
    label.appendChild(div_inside);

    const br = document.createElement('br'); //spazio per andare a capo
  
    const ref = document.getElementById("before");
    //ref.appendChild(br);
    ref.appendChild(label);
    

    const elem =document.getElementById(element.id);
    //SCRIPT PER METTERE LA SPUNTA ALLE ATTIVITA' A CUI L'UTENTE ERA ISCRITTO:
    const js = <?php echo json_encode($_GLOBALS["vect"]); ?>;  
    if(js!=null){
    for(x of js)
        if(element.id==x.id_attivita)
            checkbox.checked = true;
        }}
  }



</script>

</body>
</html>