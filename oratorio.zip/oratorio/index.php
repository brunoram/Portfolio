<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
    <link rel="stylesheet" href="css/index.css"/>
   <!-- <link rel="stylesheet" href="style.css"/> -->
   <link rel="stylesheet" href="css/button_home.css"/> 
  </head>

  

  <body>
  
  <header>
      
      <div id="sx">
      <img src="css/img/logo.png" height="85%" width="37%">
  <button class="button_home" onclick="window.location.href = 'index.php';">Home</button>
</div>
  <div id="dx">
      <h1>ORATORIO "DON BOSCO"</h1>
  <h3>Parrocchia "B.M.V. dell'Angelo Annunziata" - Biancavilla</h3>
</div>
  

  </header>

    <div id="box-flex">
        <a href="crea_utente.php"  class="btns myButton">Iscrivi nuovo utente</a>
        <a href="lista_attività.php" class="btns myButton">Lista attività</a>
        <a href="lista_iscritti.php" class="btns myButton">Lista iscritti</a>
    </div>
  </body>

  <footer>
    <div class="footer_div">
        Parrocchia "B.M.V. dall'Angelo Annunziata" - Oratorio "Don Bosco" - Developed by B.R.
</div>
</footer>
  </html>