<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "oratorio";
       
    if (isset($_POST))
    {
        $conn = new mysqli($servername, $username, $password, $dbname);
        if (mysqli_connect_errno()) 
        {
            printf("Connect failed: %s\n", mysqli_connect_error());
            exit();
        }
        

        $utf = mysqli_query($conn, "set character set utf8");
        $nome=mysqli_real_escape_string($conn,$_POST["nome"]);
        $cognome=mysqli_real_escape_string($conn,$_POST["cognome"]);
        $sesso=mysqli_real_escape_string($conn,$_POST["sesso"]);
        $luogo=mysqli_real_escape_string($conn,$_POST["luogo"]);
        $data=mysqli_real_escape_string($conn,$_POST["data"]);
        $indirizzo=mysqli_real_escape_string($conn,$_POST["indirizzo"]);
        $telefono=mysqli_real_escape_string($conn,$_POST["telefono"]);
        $ruolo=mysqli_real_escape_string($conn,$_POST["ruolo"]);
        $autorizzazione=mysqli_real_escape_string($conn,$_POST["autorizzazione"]);
        $soldi=mysqli_real_escape_string($conn,$_POST["soldi"]);
        
        if ($r=mysqli_query($conn, "INSERT INTO utente (nome,cognome,sesso,luogo_nascita,data_nascita,indirizzo,telefono,ruolo,autorizzazione,soldi) VALUES
         ('$nome', '$cognome', '$sesso', '$luogo', '$data', '$indirizzo', '$telefono', '$ruolo', '$autorizzazione', '$soldi')")===TRUE)
         {
            $id_utente=mysqli_query ($conn, "SELECT id from utente where nome = '$nome' AND cognome = '$cognome' AND data_nascita = '$data'");
            $id=mysqli_fetch_row($id_utente);
            $_SESSION["user"]= $id[0];
            printf($id[0]); //funziona

             //SCELTA ATTIVITA, SE SI AGGIUNGE UNA NUOVA ATTIVITA ALLE 11 PROPOSTE, AGGIUNGERLA ANCHE QUI, CON IL RELATIVO NOME
            if (isset($_POST["Calcio"]))
            {
        
                $id_utente=$_SESSION["user"];
                $id=$_POST["Calcio"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");
                
                
            }
            if (isset($_POST["Pallavolo"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["Pallavolo"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");
                
            }
            if (isset($_POST["Basket"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["Basket"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");        
            }

            if (isset($_POST["Teatro"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["Teatro"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')"); 
            }   
            
            if (isset($_POST["Canto"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["Canto"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')"); 
            } 


            if (isset($_POST["Ballo"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["Ballo"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");
            }
            if (isset($_POST["Musica"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["Musica"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");
            }
            if (isset($_POST["PingPong"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["PingPong"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");  
            }
            if (isset($_POST["Biliardino"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["Biliardino"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");       
            }
            if (isset($_POST["Informatica"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["Informatica"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");
            }

            if (isset($_POST["Lavoretti_artistici"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["Lavoretti_artistici"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");    
            }
            if (isset($_POST["Doposcuola"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["Doposcuola"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");    
            }
            if (isset($_POST["AC"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["AC"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");    
            }
            if (isset($_POST["Catechismo"]))
            {
                $id_utente=$_SESSION["user"];
                $id=$_POST["Catechismo"]; 
                $insert=mysqli_query($conn, "INSERT INTO sceglie (id_utente, id_attivita) VALUES ('$id_utente', '$id')");    
            }

        
                sleep(1);
                header("location: crea_utente.php");
         }
       
        

       

        mysqli_close($conn);
    }

?>