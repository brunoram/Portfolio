<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Crea utente</title>
   <!-- <link rel="stylesheet" href="crea_utente.css"/> -->
    <link rel="stylesheet" href="css/crea_utente.css"/>
    <script src="js\crea_utente.js" defer="true"></script>
    <link rel="stylesheet" href="css/button_home.css"/> 
  </head>

  

  <body>
  
  <header>
      
      <div id="sx">
      <img src="css/img/logo.png" height="85%" width="37%">
  <button class="button_home" onclick="window.location.href = 'index.php';">Home</button>
</div>
  <div id="dx">
      <h1>ORATORIO "DON BOSCO"</h1>
  <h3>Parrocchia "B.M.V. dell'Angelo Annunziata" - Biancavilla</h3>
</div>
  

  </header>
  <section id="crea_utente">
                    <h2 id="p-title">Iscrivi nuovo utente</h2>
                    <p>Per il ruolo si intende:<br>
                        animatore: 15-18 anni<br>
                        educatore: >18anni<br>
                        custode: uomini <br>
                        assistente: donne<br>
                        utente: un qualunque ragazzo iscritto senza alcuna responsabilità all'interno dell'oratorio
                    </p>
                    <div id="container">
            <form id="new_utente" autocomplete="off" method="POST" action="iscrivi_utente.php">
                <div id="ruolo">
           <strong>Ruolo:</strong><br>
                <input type="radio" name="ruolo" value="Utente" checked> <span class="bold">Utente normale</span><br>
                <input type="radio" name="ruolo" value="Educatore"> Educatore adulto<br>
                <input type="radio" name="ruolo" value="Animatore"> Animatore<br>
                <input type="radio" name="ruolo" value="Custode"> Custode<br>
                <input type="radio" name="ruolo" value="Assistente"> Assistente<br>
                <input type="radio" name="ruolo" value="Insegnante"> Insegnante dopo-scuola<br>
                </div>
                <br><br><strong>Nome:</strong><br>
                <input class="form-field" type="text" name="nome"><br>
                <strong>Cognome:</strong> <br>
                <input class="form-field" type="text" name="cognome"><br>
                <strong>Sesso(m/f):</strong> <br>
            <input class="form-field" type="text" name="sesso"><br>
            <strong>Luogo di nascita:</strong> <br>
                <input class="form-field" type="text" name="luogo"><br>
                <strong>Data di nascita(gg/mm/aaaa):</strong> <br>
                <input class="form-field" type="text" name="data"><br>
                <strong>Indirizzo:</strong> <br>
                <input class="form-field" type="text" name="indirizzo"><br>
                <strong>Telefono:</strong> <br>
                <input class="form-field" type="text" name="telefono"><br>
                <strong>Può andare da solo a casa?(si/no):</strong> <br>
                <input class="form-field" type="text" name="autorizzazione"><br>
                <strong>Soldi(si/no):</strong> <br>
                <input class="form-field" type="text" name="soldi"><br>
            <span>Seleziona le attività a cui si vuole iscrivere l'utente:</span><br>
                <!-- Inserire checkbox attività dinamicamente -->
                <div id="before" class="control-group">

                </div>
                <input class="myButton" type="submit" name="submit" value="Iscrivi">
           </form>
        </div>
                </section>
 


  </body>

  <footer>
    <div class="footer_div">
        Parrocchia "B.M.V. dall'Angelo Annunziata" - Oratorio "Don Bosco" - Developed by B.R.
</div>
</footer>
  </html>