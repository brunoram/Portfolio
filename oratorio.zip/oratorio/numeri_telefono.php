<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Iscritti</title>
    
   <link rel="stylesheet" href="css/elenco_iscritti_attività.css"/> 
   <script src="js\elenco_iscritti_attività.js" defer="true"></script> 
   <link rel="stylesheet" href="css/button_home.css"/>
   <link rel="stylesheet" href="css/num.css"/>  
  </head>

  

  <body>
  <?php 
 $servername="localhost";
 $username="root";
 $password="";
 $dbname="oratorio";

 $conn=new mysqli($servername, $username, $password, $dbname);
 if($conn->connect_error)
 {
      die ("Connection failed " .$conn->connect_error);
 }
 

    //RICERCA NUMERI DI TELEFONO;
    $utf = mysqli_query($conn, "set character set utf8");
    $check = mysqli_query($conn, "SELECT DISTINCT telefono from utente");
    $row_cnt = mysqli_num_rows($check);
    while($riga=mysqli_fetch_assoc($check))
     {
        $vector[]=$riga;
        
      }

mysqli_free_result($check);
mysqli_close($conn);
@$_GLOBALS["tel"]=$vector;   
@$_GLOBALS["num"]=$row_cnt;
 
 ?>

  <header>

  <h1>ORATORIO "DON BOSCO"</h1>
  <h3>Parrocchia "B.M.V. dell'Angelo Annunziata" - Biancavilla</h3>
  <button id="btn" class="button_home" onclick="window.location.href = 'index.php';">Home</button>
  </header>


    <div id="grande">

    

</div>



<script> 
const js = <?php echo json_encode($_GLOBALS["tel"]); ?>;  
const count= <?php echo json_encode($_GLOBALS["num"]); ?>;

const count_line = document.createElement('p');
count_line.textContent="Totale numeri di cellulare: "+count;
const butt=document.getElementById('btn');
butt.appendChild(count_line);

const first=document.createElement('div');
        first.classList.add("row");
        const first_info=document.createElement('div');
        first_info.classList.add("div_info");
       
        const frow=document.createElement('div');
        frow.classList.add("row");
        
        const f1=document.createElement('p');
        f1.textContent= "Telefono";
        f1.classList.add("first");
        
        const box=document.querySelector("#grande");
        box.appendChild(frow);
        frow.appendChild(first);
        first.appendChild(first_info);
        first_info.appendChild(f1);
        
for(x of js)
        {
           

        //div riga singolo elemento
        
        const div_row=document.createElement('div');
        div_row.classList.add("row");
        //nome e cognome
        const div_info=document.createElement('div');
    
        div_info.classList.add("div_info");
        const id=document.createElement('a');
        id.classList.add('num');
        const uri = '';
        const encoded = encodeURI(uri);
        const number ="39"+x.telefono;
        const link= "https://api.whatsapp.com/send?phone="+number+"&text="+encoded;
        id.setAttribute('href', link);
        id.innerHTML = x.telefono;
        
       
        div_info.appendChild(id);       
        div_row.appendChild(div_info);
 
        box.appendChild(div_row);

        }
</script>

</body>
</html>

