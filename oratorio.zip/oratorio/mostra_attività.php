<?php

 $servername="localhost";
 $username="root";
 $password="";
 $dbname="oratorio";

 $vector= array();
 
$conn=new mysqli($servername, $username, $password, $dbname);
 if($conn->connect_error)
 {
      die ("Connection failed " .$conn->connect_error);
 }

 $utf = mysqli_query($conn, "set character set utf8");

 $ris = mysqli_query($conn, "SELECT nome, url_image, id from attivita");

 while($riga=mysqli_fetch_assoc($ris))
     {
        $vector[]=$riga;
        
      }

mysqli_free_result($ris);
mysqli_close($conn);
echo json_encode($vector);    
?>