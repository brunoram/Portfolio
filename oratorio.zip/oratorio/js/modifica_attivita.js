/*------------FUNZIONE 2 prendo i dati dala $_GET ----------------------------------------*/
function onLoadGet()
{
  
  window.addEventListener("load", fetch_modificaValue);
}
onLoadGet();


function fetch_modificaValue()
{
  fetch("http://localhost/oratorio/modifica_utente.php").then(onResponse).then(check_att);
}

function onResponse(response){
  
  return response.json();
}

function check_att(json){
    for(x of json)
    {
        console.log(x);
        const c = document.querySelectorAll('input[type="checkbox"]');
        for (const i = 0; i < c.length; i++) 
        {
            console.log(c.id);
            if(c.id==x.id_attivita)
                c.checked = true;
        }

    }

}
