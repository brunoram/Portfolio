function mostraInfo()
{
    fetch("http://localhost/oratorio/mostra_attività.php").then(onResponse).then(onJSON);
}

    function onResponse(response)
    {
        
        return response.json();
    }

    function onJSON(json)
    {
        len= json.length;
        console.log(json);
        for(x of json)
        {
           
           const nome = x.nome;
           

        //div riga singolo elemento
        const div_row=document.createElement('div');
        div_row.classList.add("row");
        //div per immagine attività
        const div_img=document.createElement('div');
        div_img.classList.add("div_img");
      
        const img=document.createElement('img');
        img.classList.add("image");
        img.src=x.url_image;
        

       
        //nome attività
        const div_info=document.createElement('div');
        div_info.classList.add("div_info");
       // div_info.classList.add("div_info");
        const a = document.createElement('a');
        var link = document.createTextNode(x.nome); 
        a.appendChild(link);
        a.title = x.nome;
        a.href = "elenco_iscritti_attività.php?id="+x.id;
        
        div_img.appendChild(img); 
        div_row.appendChild(div_img);
        
        div_info.appendChild(a);
        
        
        div_row.appendChild(div_info);
        
        
       
        const box=document.querySelector("#grande");
        box.appendChild(div_row);

        }
        
    }
    


window.onload=mostraInfo();