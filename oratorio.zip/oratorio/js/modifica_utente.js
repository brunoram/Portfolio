/*
    Funzione 1: al caricamento della pagina, 
    una fetch richiede al db l'elenco delle attività
    e genera delle checkbox nel form

    Funzione 2: prendo i vecchi dati della $_GET dal PHP e li inserisco come value nei vari campi input del form

    Funzione 3: al submit "Modifica", si invia una post al db
    facendo modificare l'utente.
*/


//----------------------------FUNZIONE 1: genero checkbox-------------------------
/*function onLoadCheckbox()
{
  
  window.addEventListener("load", fetch_mostraRaccolte);
}
onLoadCheckbox();

function fetch_mostraRaccolte()
{
  fetch("http://localhost/oratorio/checkbox_attività.php").then(onResponse).then(onJSON);
}

function onResponse(response){
  
  return response.json();
}

function onJSON(json){
    const form =document.querySelector("new_utente");
  for(let element of json)
  {
  
    const nome = document.createElement('span'); //nome attività
    nome.innerText=element.nome;
    nome.id="act";

    const checkbox = document.createElement('input');
    checkbox.type = "checkbox";
    checkbox.name = element.nome;
    checkbox.value = element.id;
    checkbox.id = element.id;
    
    const br = document.createElement('br'); //spazio per andare a capo
  
    const ref = document.getElementById("before");
    ref.appendChild(br);
    ref.appendChild(nome);
    ref.appendChild(checkbox);
    const elem =document.getElementById(element.id);
    console.log("JS SCRIPT");
  }
}
*/




/*------------FUNZIONE 3 fetch al submit ----------------------------------------*/

function onSubmitForm(){
    const form=document.querySelector("#new_utente");
    form.addEventListener('submit', inviaForm);
}

function inviaForm(){
    const form = new FormData(document.querySelector('#new_utente'));
   
    fetch('http://localhost/oratorio/db_modifica_utente.php',{
        method: "POST",
        body: form
      })
}