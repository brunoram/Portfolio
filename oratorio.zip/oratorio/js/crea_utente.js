/*
    Funzione 1: al caricamento della pagina, 
    una fetch richiede al db l'elenco delle attività
    e genera delle checkbox nel form

    Funzione 2: al submit "Iscrivi", si invia una post al db
    facendo inserire il nuovo utente.
*/


//----------------------------FUNZIONE 1: genero checkbox-------------------------
function onLoadCheckbox()
{
  
  window.addEventListener("load", fetch_mostraRaccolte);
}
onLoadCheckbox();

function fetch_mostraRaccolte()
{
  fetch("http://localhost/oratorio/checkbox_attività.php").then(onResponse).then(onJSON);
}

function onResponse(response){
  
  return response.json();
}

function onJSON(json){
    const form =document.querySelector("new_utente");
  for(let element of json)
  {
    const label = document.createElement('label');  //label attività
    label.classList.add("control", "control-checkbox");

    const nome = document.createElement('span'); //nome attività
    nome.innerText=element.nome;
    nome.id="act";

    label.appendChild(nome);

    const checkbox = document.createElement('input');
    checkbox.type = "checkbox";
    checkbox.name = element.nome;
    checkbox.value = element.id;
    checkbox.id = element.id;

    label.appendChild(checkbox);

    const div_inside = document.createElement('div');
    div_inside.classList.add("control_indicator");
    
    label.appendChild(div_inside);

    const br = document.createElement('br'); //spazio per andare a capo
  
    const ref = document.getElementById("before");
    //ref.appendChild(br);
    ref.appendChild(label);
    const elem =document.getElementById(element.id);
   
  }
}

/*------------FUNZIONE 2 fetch al submit ----------------------------------------*/

function onSubmitForm(){
    const form=document.querySelector("#new_utente");
    form.addEventListener('submit', inviaForm);
}

function inviaForm(){
    const form = new FormData(document.querySelector('#new_utente'));
   
    fetch('http://localhost/oratorio/iscrivi_utente.php',{
        method: "POST",
        body: form
      })
}