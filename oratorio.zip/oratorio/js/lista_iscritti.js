/*mostraInfo();

function mostraInfo()
{
    fetch("http://localhost/oratorio/mostra_iscritti.php").then(onResponse).then(onJSON);
}

    function onResponse(response)
    {
        
        return response.json();
    }

    function onJSON(json)
    {
        alert(json);
        for(x of json)
        {  
        var row = document.createElement("tr");
           var id = document.createElement("td");
           var cell_id = document.createTextNode(x.id);
           var ruolo = document.createElement("td");
           var cell_ruolo = document.createTextNode(x.ruolo);
           var nome = document.createElement("td");
           var cell_nome = document.createTextNode(x.nome);
           var cognome = document.createElement("td");
           var cell_cognome = document.createTextNode(x.cognome);
          
           var sesso = document.createElement("td");
           var cell_sesso = document.createTextNode(x.sesso);
           var data = document.createElement("td");
           var cell_data = document.createTextNode(x.data_nascita);
           var luogo = document.createElement("td");
           var cell_luogo = document.createTextNode(x.luogo_nascita);
           var indirizzo = document.createElement("td");
           var cell_indirizzo = document.createTextNode(x.indirizzo);
           var telefono = document.createElement("td");
           var cell_telefono = document.createTextNode(x.telefono);
           var soldi = document.createElement("td");
           var cell_soldi = document.createTextNode(x.soldi);
           var autorizzazione = document.createElement("td");
           var cell_autorizzazione = document.createTextNode(x.autorizzazione);
           
           id.appendChild(cell_id);
                 row.appendChild(id);
           ruolo.appendChild(cell_ruolo);
                 row.appendChild(ruolo);
           nome.appendChild(cell_nome);
                 row.appendChild(nome);
           cognome.appendChild(cell_cognome);
                 row.appendChild(cognome);
           
           sesso.appendChild(cell_sesso);
                 row.appendChild(sesso);
           data.appendChild(cell_data);
                 row.appendChild(data);
           luogo.appendChild(cell_luogo);
                 row.appendChild(luogo);
           indirizzo.appendChild(cell_indirizzo);
                 row.appendChild(indirizzo);
           telefono.appendChild(cell_telefono);
                 row.appendChild(telefono);
           soldi.appendChild(cell_soldi);
                 row.appendChild(soldi);
           autorizzazione.appendChild(cell_autorizzazione);
                 row.appendChild(autorizzazione);
           const the=document.getElementById("the");
           the.appendChild(row);

          

        }
       
        $(document).ready( function () {
            $('#table').DataTable();
        } );
 }
        








        //div riga singolo elemento
        /*const div_row=document.createElement('div');
        div_row.classList.add("row");
 
        //nome utente
        /*const div_info=document.createElement('div');
    
        div_info.classList.add("div_info");
        const name=document.createElement('p');
        name.textContent= x.nome;
        const cognome=document.createElement('p');
        cognome.textContent= x.cognome;
        const data=document.createElement('p');
        data.textContent= x.data_nascita; 
        
        div_info.appendChild(name);
        div_info.appendChild(cognome);
        div_info.appendChild(data);
        
        div_row.appendChild(div_info);
        
        

        }
        
    }
    

*/
      