<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lista attività</title>
    <link rel="stylesheet" href="css/lista_attivita.css"/>
   <!-- <link rel="stylesheet" href="style.css"/> -->
   <script src="js\lista_attività.js" defer="true"></script>
   <link rel="stylesheet" href="css/button_home.css"/> 
  </head>

  

  <body>
  
  <header>
      
      <div id="sx">
      <img src="css/img/logo.png" height="85%" width="37%">
  <button class="button_home" onclick="window.location.href = 'index.php';">Home</button>
</div>
  <div id="dx">
      <h1>ORATORIO "DON BOSCO"</h1>
  <h3>Parrocchia "B.M.V. dell'Angelo Annunziata" - Biancavilla</h3>
</div>
  

  </header>
<h2>Clicca sul nome di un'attività per visualizzare tutti gli iscritti.</h2>
    <div id="grande">

    

</div>





</body>
</html>