<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/logout', 'Auth\LoginController@logout');
Route::get('/search', 'SearchController@show');

Route::get('/onload', 'HomeController@onload'); 
Route::get('/create/{titolo}', 'HomeController@create');

Route::get('/api_search/{stringa}', 'SearchController@api_search');
Route::post('/insert', 'SearchController@insert');

Route::get('/collection/{title}/{id_coll}', 'CollectionController@row_collection');
Route::get('/delete/{id_cont}/{id_coll}', 'CollectionController@delete');


