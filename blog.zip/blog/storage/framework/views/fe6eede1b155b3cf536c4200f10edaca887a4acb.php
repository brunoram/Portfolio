<link href="<?php echo e(asset('css/search.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('js/search.js')); ?>" defer="true"></script>
<?php $__env->startSection('tag-h1'); ?>
    <h1>Ricerca libri</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tag-h2'); ?>
    <h2 class="f">Inserisci titolo volume:</h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('search'); ?>
<form id="search_form">
        <?php echo csrf_field(); ?>
                <input type="search" name="ricerca" id="search_bar">
                <input type="submit" class="ricerca" name="submit" value="Inizia la ricerca">
        </form> </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('box-flex'); ?>
    <div id="box-flex"> </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/search.blade.php ENDPATH**/ ?>