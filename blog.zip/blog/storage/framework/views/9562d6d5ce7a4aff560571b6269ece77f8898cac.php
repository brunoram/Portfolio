<link href="<?php echo e(asset('css/collection.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('js/collection.js')); ?>" defer="true"></script>
<script> const data= <?php echo json_encode($array); ?> </script>
<?php $__env->startSection('tag-h1'); ?>
    <h1>Raccolte</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tag-h2'); ?>
    <div id="cont">
        <h1 id="tit_racc">Raccolta: <?php echo e($title); ?> </h1>
        <h2>Elenco contenuti:</h2>
        <h3>Clicca sul titolo o sull'immagine di un libro per visualizzare le sue informazioni.</h3>
        <h3>Clicca su "Elimina libro" per eliminare il libro dalla raccolta.</h3>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('box-flex'); ?>
    <div id="box-flex"> </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views//collection.blade.php ENDPATH**/ ?>