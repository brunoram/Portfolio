<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="<?php echo e(asset('css/welcome.css')); ?>" rel="stylesheet">
        <title>Laravel</title>

        
        <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:400,700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Fredericka+the+Great&display=swap" rel="stylesheet">
        
    </head>
    <body>
     <div class="title m-b-md">
            <div class="bord">
                    <p id="title"> Benvenuto su MyLibrary</p>
                    <p id="subtitle">Il posto ideale per scegliere le tue prossime letture </p>
            </div> 
        <div class="content">
            <div class="links">
                <?php if(Route::has('login')): ?>
                <div class="links">
                    <?php if(auth()->guard()->check()): ?>
                        <a class="subst myButton" href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a class="log myButton" href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a class="subst myButton" href="<?php echo e(route('register')); ?>">Registrati</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            </div>
        </div>
     </div>
           

           
                

                
          
        
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/welcome.blade.php ENDPATH**/ ?>