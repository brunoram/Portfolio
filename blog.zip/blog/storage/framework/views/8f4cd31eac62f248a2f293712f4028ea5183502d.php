<link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('js/home.js')); ?>" rel="script" defer="true">
<link href="<?php echo e(asset('js/home_inserisci.js')); ?>" rel="script" defer="true">


<?php $__env->startSection('tag-h2'); ?>
    <h2>Ecco le tue raccolte:</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('box-flex'); ?>
    <div id="box-flex"> </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('crea_raccolta'); ?>
    <section id="crea_raccolta"> 
    <h2>Crea nuova raccolta: </h2>
            <form id="new_raccolta">
                <label> Titolo raccolta  <input type="text" id="create_bar" name="titolo_raccolta"></label>
                <input type="submit" class="ricerca" name="invia" value="Invia">
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views//home.blade.php ENDPATH**/ ?>