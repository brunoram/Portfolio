<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset('css/images/favicon.ico')); ?>" />
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
</head>
<body>
    <header> 
            <div id= "div_max_header">
                  <div id="div_header"> <h1 id="firsth1">MY LIBRARY</h1> 
                  <img id="img_cont" src="<?php echo e(asset('css/images/MyLibrary-logo-giglio.png')); ?>"> <h1 id="secondh1">La tua libreria online</h1> 
                   
                 </div>
    </header>
            <section id="blank">
              
            </section>  
            <div id="blue_title">
                <?php echo $__env->yieldContent('tag-h1'); ?>
            </div>

            <article>
                 <section id="men">
                 <ul class="menu">
                    <li><a href="/home">Home</a></li>
                    <li><a href="/search">Ricerca</li>
                    <li><a href="/logout">Logout</a></li>
                </ul>
                </section>

                <section id="contenuto">
                    <?php echo $__env->yieldContent('tag-h2'); ?>
                    <?php echo $__env->yieldContent('search'); ?>
                    <?php echo $__env->yieldContent('box-flex'); ?>         
                    <?php echo $__env->yieldContent('crea_raccolta'); ?>
                <section id="right"> </section>
                </section>
</article>



    <footer>
       <p> Made by BR Corp. ©2019</p>
    </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/layouts/box.blade.php ENDPATH**/ ?>