function creaRaccolta()
{
  const form=document.querySelector("#new_raccolta");
  form.addEventListener('submit', inserisci);
}
//Fetch alla funzione create() dell'HomeController.php, per creare una nuova raccolta dalla home
function inserisci()
{ 
 const form = document.querySelector("#new_raccolta");
 const title = form.titolo_raccolta.value;
    fetch('/create/'+form.titolo_raccolta.value);
}
creaRaccolta();  
