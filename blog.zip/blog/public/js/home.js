
function onLoadBox()
{
  const box =document.querySelector("#box-flex");
  window.addEventListener("load", fetch_mostraRaccolte);
}
onLoadBox();
//Fetch alla funzione onload() dell'HomeController.php
function fetch_mostraRaccolte()
{
  fetch("/onload/").then(onResponse).then(onJSON);
}

function onResponse(response){
  
  return response.json();
}
//Creazione div e visualizzazione delle raccolte dell'utente nella home
function onJSON(json){
  const box_flex=document.querySelector("#box-flex");
  for(let element of json)
  {
    
  const div=document.createElement('div');
  div.classList.add("collection");

  const link=document.createElement('a');
  link.classList.add("links");
  link.href="/collection/"+element.title+"/"+element.collection_id;
  
  const img=document.createElement('img');
  img.classList.add("image");
  img.src=element.img_url;

  p=document.createElement('p');
  var node = document.createTextNode(element.title);
  
  p.appendChild(node);
  div.appendChild(link);
  link.appendChild(img);
  link.appendChild(p);
  box_flex.appendChild(div);
  }
}