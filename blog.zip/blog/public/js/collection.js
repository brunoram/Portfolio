function mostraInfo()
{
      
    for(x of data)
    {
        const titolo=x.title;
        const autore=x.author;
        const editore= x.publisher;
        const pagine=x.pages;
        const url_image=x.img_url;
        const id_google=x.google_id;
      
       const id_contenuto=x.content_id;
       const id_raccolta=x.collection_id;
       

    //div riga singolo elemento
    const div_row=document.createElement('div');
    div_row.classList.add("row");
    
    //div per immagine di copertina libro
    const div_img=document.createElement('div');
    div_img.classList.add("div_img");
  
    const img=document.createElement('img');
    img.classList.add("image");
    img.src=url_image;
    
    
    //titolo libro
    const div_title=document.createElement('div');
    div_title.classList.add("div_title");
    const title=document.createElement('p');
    title.classList.add("titolo_libro");
    title.textContent="Titolo: "+titolo;
   
    //informazioni libro
    const div_info=document.createElement('div');
    div_info.classList.add("hidden");
   
   
    const id=document.createElement('p');
    id.textContent="Google ID: "+id_google;
    const author=document.createElement('p');
    author.textContent="Autore: "+autore;
    const publisher=document.createElement('p');
    publisher.textContent="Editore: "+editore;
    const pages=document.createElement('p');
    pages.textContent="Pagine: "+pagine;
    
    //pulsante elimina contenuto
    const div_delete=document.createElement('div');
    div_delete.classList.add("delete");
    const button=document.createElement('button');
    button.classList.add("btn");
    button.type="submit";
    button.value=id_contenuto;
    button.setAttribute("data-collect-id", id_raccolta);
    button.textContent="Elimina libro";

    div_img.appendChild(img); 
    div_row.appendChild(div_img);
    div_title.appendChild(title);
    div_row.appendChild(div_title);  
    div_info.appendChild(id);
    
    div_info.appendChild(author);
    div_info.appendChild(publisher);
    div_row.appendChild(div_info);
    div_delete.appendChild(button);
    div_row.appendChild(div_delete);
   
    const box=document.querySelector("#box-flex");
    box.appendChild(div_row);

    }
    const btn=document.querySelectorAll(".btn");
    for(butt of btn)
{
butt.addEventListener('click', elimina);
}

const imgs=document.querySelectorAll(".image");
for(x of imgs){
    x.addEventListener('click', info);
}

const tit=document.querySelectorAll(".titolo_libro");
for(y of tit){
    y.addEventListener('click', info);
}
}

window.onload=mostraInfo();


function elimina(event)
{
   
   const id_cont=event.currentTarget.value;
   const id_racc=event.currentTarget.dataset.collectId;
   const tit_racc=document.querySelector("#tit_racc");
   const titolo=tit_racc.textContent.slice(10,);
   
   fetch("/delete/"+id_cont+"/"+id_racc);
   
   document.location.reload(false);
  
}

function info(event)
{
    const cliccato=event.currentTarget;
   const div_row= cliccato.parentNode.parentNode;
    div_row.style.width="90%";
    const div_inf=div_row.childNodes[2];  
    div_inf.classList.remove("hidden");
    div_inf.classList.add("div_info");
    cliccato.removeEventListener("click", info);
    cliccato.addEventListener("click", scambia);
}

function scambia(event)
{
    const cliccato=event.currentTarget;
    const row= cliccato.parentNode.parentNode;
    row.style.width="70%";
    const div_inf=row.childNodes[2];
    div_inf.classList.remove("div_info");
    div_inf.classList.add("hidden");
    cliccato.removeEventListener("click", scambia);
    cliccato.addEventListener("click", info);
}

