<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('user_id');
            $table->string('name');
            $table->string('surname');
            $table->string('email')->unique();
            $table->string('tel');
            $table->string('username')->unique();
           
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create('collections', function (Blueprint $table) {
            $table->unsignedBigInteger('user_id');
            $table->foreign('user_id')->references('user_id')->on('users');
            $table->bigIncrements('collection_id');
           
         
            $table->string('title');
            $table->string('img_url');
            $table->timestamps();
        });
        
//composite primary key: $table->primary(["id", "secon"]);
        Schema::create('contents', function (Blueprint $table) {
            $table->unsignedBigInteger('collection_id');
            $table->foreign('collection_id')->references('collection_id')->on('collections');
            $table->bigIncrements('content_id');
            
            $table->string('title');
            $table->string('author');
            $table->string('publisher');
            $table->string('pages');
            $table->string('google_id');
            $table->string('img_url');
            $table->timestamps();
        });
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('collections');
        Schema::dropIfExists('contents');
    }
}
