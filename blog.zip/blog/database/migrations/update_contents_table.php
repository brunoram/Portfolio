<?php
//NON FUNZIONA, AGGIUNGERE PRIMARY KEY MULTIPLA A MANO DA PHPMYADMIN 
//nella tabella CONTENTS, alle colonne COLLECTION_ID e CONTENT_ID
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateContent extends Migration{

 /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

DB::statement('ALTER TABLE  `contents` DROP PRIMARY KEY , ADD PRIMARY KEY (  `collection_id` ,  `content_id`) ;');
    }

    public function down() 
    {
        DB::statement('ALTER TABLE  `contents` DROP PRIMARY KEY, ADD PRIMARY KEY (  `content_id`);');
    }
}