<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Content extends Model
{
    public function Collections(){
        return $this->belongsTo(Collection::get());
    }
}
