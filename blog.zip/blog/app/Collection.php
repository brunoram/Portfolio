<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Collection extends Model
{
    public function Users()
    {
return $this->belongsTo(User::get());
    }

    public function Contents()
    {
        return $this->hasMany(Content::get());
    }
}
