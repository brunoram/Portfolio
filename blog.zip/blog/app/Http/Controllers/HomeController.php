<?php

namespace App\Http\Controllers;
use App\User;
use Auth;
use App\Collection;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use DB;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $user_get_name= \Auth::user();
        $data=$user_get_name["name"];
        return view('home', ['name' => $data]);
    }

    //Funzione caricamento raccolte nella home (file js di riferimento: home.js)
    public function onload(Request $request)
    {
       $user_id = \Auth::id();
       $collections = Collection::where("user_id", $user_id)
            ->get();
       $racc=json_encode($collections);     
       return $racc;
    }
    //Funzione creazione nuova raccolta dalla home (file js di riferimento: home_inserisci.js)
    public function create($titolo)
    {
        $user_id = \Auth::id();
        $default_img_url="https://as1.ftcdn.net/jpg/01/74/44/62/500_F_174446259_iYCcLsC7BKaIlSKb7hScY80hNQdMpZgN.jpg";
        DB::Table("Collections")
            ->insert(["user_id"=>$user_id,"title"=>$titolo, "img_url"=>$default_img_url]);
    }

}
