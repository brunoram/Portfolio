<?php

namespace App\Http\Controllers;
use App\User;
use App\BoxModel;
use Illuminate\Http\Request;
use DB;

class BoxController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }
   
   


}