<?php

namespace App\Http\Controllers;

use App\CollectionModel;

use Illuminate\Http\Request;
use DB;
class CollectionController extends Controller
{
    var $id_coll;

    public function __construct()
    {
        $this->middleware('auth');
    }
  
//Funzione che mostra i contenuti della raccolta fetchata 
/*
const titolo=x.titolo;
            const autore=x.autore;
            const editore= x.editore;
            const pagine=x.pagine;
            const url_image=x.url_image;
            const id_google=x.id_google;
          
           const id_contenuto=x.id_contenuto;
           const id_raccolta=x.id_raccolta;
*/
    public function row_collection($title, $id_coll)
    {
        $contents=DB::Table('Contents')
        ->where("collection_id", $id_coll)
        ->get();
        $data=$contents->toArray(); 
     //print_r($data[0]->title);
    
        return view('/collection', ["array" => $data, "title" => $title]);
    }
    

//Funzione eliminazione contenuto da raccolta
    public function delete($id_cont,$id_coll)
    {
        DB::Table("Contents")
        ->where('content_id','=', $id_cont)
        ->where('collection_id','=', $id_coll)
        ->delete();
    }
}
