<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function show()
    {
        return view('search');
    }

    public function api_search($stringa)
    {   
        $string=urlencode($stringa);
        $api_key="AIzaSyCPVsFOwCEKbbO_SXHR02nMVnwCTxUBkRc";
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL,"https://www.googleapis.com/books/v1/volumes?q=".$string.'&key='.$api_key);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            
        $result = curl_exec($curl);
        
        curl_close($curl);
        return $result;
    }

    public function insert()
    {
        if(isset($_POST))
    {
        $titolo=$_POST["titolo"];
        $autore=$_POST["autore"];
        $editore=$_POST["editore"];
        $pagine=$_POST["pagine"];
        $tit_raccolte=$_POST["titolo_racc"];
        $url_image=$_POST["url_img"];
        $id_google=$_POST["id_google"];
        $id_raccolta=$_POST["id_raccolta"];

        $check_equal_count = DB::Table('Contents')->distinct()
            ->where('google_id', '=', $id_google)
            ->count();
        if ($check_equal_count===1)
        {
            $content_id=DB::Table('Contents')->distinct()
            ->where('google_id', '=', $id_google)
            ->first();
            $id_cont=$content_id->content_id;
            //se il contenuto già è presente in altre raccolte, l'id_contenuto rimane uguale
            //bisogna avere una primary key multipla(content_id, collection_id)
            DB::Table("Contents")
            ->insert(["collection_id"=>$id_raccolta,"content_id"=>$id_cont,"title"=>$titolo, "author"=>$autore, "publisher"=>$editore, "pages"=>$pagine, "google_id"=>$id_google, "img_url"=>$url_image]);
        }
        else
        {
            //se il contenuto non esiste nel DB, l'id contenuto sarà inserito con l'autoincrement
            DB::Table("Contents")
            ->insert(["collection_id"=>$id_raccolta,"title"=>$titolo, "author"=>$autore, "publisher"=>$editore, "pages"=>$pagine, "google_id"=>$id_google, "img_url"=>$url_image]);
        }
        //Update dell'immagine di default con quella del primo contenuto inserito in raccolta
        $default_img_url="https://as1.ftcdn.net/jpg/01/74/44/62/500_F_174446259_iYCcLsC7BKaIlSKb7hScY80hNQdMpZgN.jpg";
        DB::Table("Collections")
        ->where('collection_id','=',$id_raccolta)
        ->where('img_url','=', $default_img_url)
        ->update(['img_url'=>$url_image]);
        
    }
 }
}
