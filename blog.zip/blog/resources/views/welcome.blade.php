<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="{{ asset('css/welcome.css') }}" rel="stylesheet">
        <title>Laravel</title>

        
        <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:400,700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Fredericka+the+Great&display=swap" rel="stylesheet">
        
    </head>
    <body>
     <div class="title m-b-md">
            <div class="bord">
                    <p id="title"> Benvenuto su MyLibrary</p>
                    <p id="subtitle">Il posto ideale per scegliere le tue prossime letture </p>
            </div> 
        <div class="content">
            <div class="links">
                @if (Route::has('login'))
                <div class="links">
                    @auth
                        <a class="subst myButton" href="{{ url('/home') }}">Home</a>
                    @else
                        <a class="log myButton" href="{{ route('login') }}">Login</a>

                        @if (Route::has('register'))
                            <a class="subst myButton" href="{{ route('register') }}">Registrati</a>
                        @endif
                    @endauth
                </div>
            @endif
            </div>
        </div>
     </div>
           

           
                

                
          
        
    </body>
</html>
