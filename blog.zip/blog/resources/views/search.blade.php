@extends('layouts.box')
<link href="{{ asset('css/search.css') }}" rel="stylesheet">
<script src="{{ asset('js/search.js') }}" defer="true"></script>
@section('tag-h1')
    <h1>Ricerca libri</h1>
@endsection

@section('tag-h2')
    <h2 class="f">Inserisci titolo volume:</h2>
@endsection
@section('search')
<form id="search_form">
        @csrf
                <input type="search" name="ricerca" id="search_bar">
                <input type="submit" class="ricerca" name="submit" value="Inizia la ricerca">
        </form> </div>
@endsection
@section('box-flex')
    <div id="box-flex"> </div>
@endsection