<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="icon" href="{{ asset('css/images/favicon.ico') }}" />
    <title>{{ config('app.name', 'Laravel') }}</title>
</head>
<body>
    <header> 
            <div id= "div_max_header">
                  <div id="div_header"> <h1 id="firsth1">MY LIBRARY</h1> 
                  <img id="img_cont" src="{{ asset('css/images/MyLibrary-logo-giglio.png') }}"> <h1 id="secondh1">La tua libreria online</h1> 
                   
                 </div>
    </header>
            <section id="blank">
              
            </section>  
            <div id="blue_title">
                @yield('tag-h1')
            </div>

            <article>
                 <section id="men">
                 <ul class="menu">
                    <li><a href="/home">Home</a></li>
                    <li><a href="/search">Ricerca</li>
                    <li><a href="/logout">Logout</a></li>
                </ul>
                </section>

                <section id="contenuto">
                    @yield('tag-h2')
                    @yield('search')
                    @yield('box-flex')         
                    @yield('crea_raccolta')
                <section id="right"> </section>
                </section>
</article>



    <footer>
       <p> Made by BR Corp. ©2019</p>
    </footer>
</body>
</html>
