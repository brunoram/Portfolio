@extends('layouts.box')
<link href="{{ asset('css/collection.css') }}" rel="stylesheet">
<script src="{{ asset('js/collection.js') }}" defer="true"></script>
<script> const data= {!! json_encode($array) !!} </script>
@section('tag-h1')
    <h1>Raccolte</h1>
@endsection
@section('tag-h2')
    <div id="cont">
        <h1 id="tit_racc">Raccolta: {{ $title }} </h1>
        <h2>Elenco contenuti:</h2>
        <h3>Clicca sul titolo o sull'immagine di un libro per visualizzare le sue informazioni.</h3>
        <h3>Clicca su "Elimina libro" per eliminare il libro dalla raccolta.</h3>
    </div>
@endsection

@section('box-flex')
    <div id="box-flex"> </div>
@endsection

