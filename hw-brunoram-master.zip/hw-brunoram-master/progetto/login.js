
function onSubmit()
{
    document.querySelector("#login").addEventListener('submit', onLogin);
}
onSubmit();




function onLogin()
{
    const formmm=document.querySelector("#login");
    
   const form = new FormData(document.querySelector('#login'));
  
    fetch('http://localhost/progetto/login.php',{
        method: "post",
        headers: new Headers({
       "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}),
        body: form
      });
}
