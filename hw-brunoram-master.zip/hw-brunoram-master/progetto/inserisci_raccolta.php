<?php
session_start();

if(!isset($_SESSION["user"])){
    header("Location: http://localhost/progetto/login.php");
    exit();
}   

 $servername="localhost";
 $username="root";
 $password="";
 $dbname="progetto";

 $user=$_SESSION["user"];
 
 $conn=new mysqli($servername, $username, $password, $dbname);
 if($conn->connect_error)
 {
      die ("Connection failed " .$conn->connect_error);
 }

 if(isset($_GET["titolo_raccolta"])){
 $utf = mysqli_query($conn, "set character set utf8");


$title=mysqli_real_escape_string($conn,$_GET["titolo_raccolta"]);
$default_img_url="https://as1.ftcdn.net/jpg/01/74/44/62/500_F_174446259_iYCcLsC7BKaIlSKb7hScY80hNQdMpZgN.jpg";
$insert=mysqli_query($conn, "INSERT INTO raccolta (id_utente, titolo, img_url) VALUES ('$user', '$title', '$default_img_url')");


mysqli_free_result($insert);
 }
mysqli_close($conn);
?>