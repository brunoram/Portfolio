let tit_raccolte = [];
let id_raccolte = [];
titoli_raccolte();
onSubmit_search();

//FUNZIONE CHE REPERISCE I TITOLI DELLE RACCOLTE ESISTENTI
function titoli_raccolte(){
    fetch("http://localhost/progetto/mostra_raccolte.php").then(onResponse2).then(onJSON2);}
function onResponse2(response){return response.json();}

function onJSON2(json)
{for (let x of json)
    {  
        tit_raccolte.push(x.titolo);
        id_raccolte.push(x.id_raccolta);
    }
}
//FUNZIONE DI RICERCA MEDIANTE APIs GOOGLEBOOKS
function onSubmit_search()
{
    const form=document.querySelector("#search_form");
    form.addEventListener('submit', search);
}
function search(event)
{
    event.preventDefault();
    const form=document.querySelector("#search_form");
    const string=form.ricerca.value;
   
    fetch('http://localhost/progetto/do_search.php?ricerca='+string).then(onResponse).then(onJSON); 
  
}

function onResponse(response){
     
    return response.json();
}

function onJSON(json){
    
//VISUALIZZAZIONE DELLE INFORMAZIONI OTTENUTE:
    for(let element of json["items"]){
    
        //div riga singolo risultato
        const div_row=document.createElement('div');
        div_row.classList.add("row");
        //div per immagine di copertina libro
        const div_img=document.createElement('div');
        div_img.classList.add("div_img");
      
        const img=document.createElement('img');
        img.classList.add("image");
        img.src=element["volumeInfo"]["imageLinks"]["smallThumbnail"];
        //titolo libro
        const title=document.createElement('p');
        title.classList.add("titolo_libro");
        title.textContent="Titolo: "+element["volumeInfo"]["title"];
        //informazioni libro
        const div_info=document.createElement('div');
        div_info.classList.add("div_info");
        const id=document.createElement('p');
        id.textContent="Google ID: "+element["id"];
        const author=document.createElement('p');
        author.textContent="Autore: "+element["volumeInfo"]["authors"];
        const publisher=document.createElement('p');
        publisher.textContent="Editore: "+element["volumeInfo"]["publisher"];
        const pages=document.createElement('p');
        pages.textContent="Pagine: "+element["volumeInfo"]["pageCount"];
        //div per menu a tendina
        const div_select=document.createElement('div');
        div_select.classList.add("div_select");
        const tendina=document.createElement('select');
        tendina.classList.add("tendina");
        option=document.createElement('option');
        option.textContent="Seleziona";
        tendina.appendChild(option);
        const testo=document.createElement('p');
        testo.textContent="Aggiungi volume alla raccolta:";
        
        

      
        //creazione opzioni menù a tendina 
            let options=[];
            
            for(let i=0; i<tit_raccolte.length; i++)
            {
            options[i]=document.createElement('option');
            options[i].value=tit_raccolte[i];
            options[i].setAttribute("data-collect-id", id_raccolte[i]); //utilizzo il dataset per salvare l'id della raccolta, mi servirà nel php per la query al db
            options[i].textContent=tit_raccolte[i];
            
            tendina.appendChild(options[i]);
            }
        
        div_img.appendChild(img); 
        div_row.appendChild(div_img);
        div_info.appendChild(id);
        div_info.appendChild(title);  
        div_info.appendChild(author);
        div_info.appendChild(publisher);
        if(element["volumeInfo"]["publisher"]==undefined)
        {
            publisher.innerHTML="";  //elimina la voce Editore quando non presente per il volume.
        }
        div_info.appendChild(pages);
        if(element["volumeInfo"]["pageCount"]==undefined)
        {
            publisher.innerHTML="";  
        }
      
        if(element["volumeInfo"]["authors"]==undefined)
        {
            publisher.innerHTML="";  
        }
        div_row.appendChild(div_info);
        div_select.appendChild(testo);
        div_select.appendChild(tendina);
        div_row.appendChild(div_select);
       
        
        const box=document.querySelector("#box-flex");
        box.appendChild(div_row);
        select_collection();
        
    }
}


//Event Listener sulla selezione delle raccolta in cui aggiungere il volume
function select_collection()
{
    const tendina=document.querySelectorAll(".tendina");
    for(all of tendina)
    {
       all.addEventListener('change', aggiungi);
    }
    
}
function aggiungi(event){
    const tendina=event.target;
    const val=tendina.options[tendina.selectedIndex].value; //titolo_raccolta selezionato
    const id_raccolta=tendina.options[tendina.selectedIndex].dataset.collectId;
    
    const row_box= tendina.parentNode.parentNode; //seleziono il div che contiene img e info del volume 
    const child=row_box.childNodes;
        //seleziono le informazioni del volume da aggiungere al db, uso slice per eliminare le parole titolo:, autore:, ecc.
        const url_image=child[0].childNodes[0].currentSrc;
    
        const id_google=child[1].childNodes[0].textContent.slice(11,);
       
        const titolo= child[1].childNodes[1].textContent.slice(8,);
        const autore= child[1].childNodes[2].textContent.slice(8,);
        const editore=child[1].childNodes[3].textContent.slice(9,);
        const pagine=child[1].childNodes[4].textContent.slice(8,);
        
        var form = new FormData();
        form.append('titolo_racc', val); form.append("id_google", id_google);form.append('titolo', titolo); 
         form.append('autore', autore); form.append('editore', editore); form.append('pagine', pagine);
         form.append('url_img', url_image);form.append('id_raccolta', id_raccolta);
        fetch('http://localhost/progetto/inserisci_contenuto.php',{
        method: "post",
        body: form
      });
    }


    