<?php
   
   session_start();
        
   if(!isset($_SESSION["user"]))
   {
       header("Location: http://localhost/progetto/login.php");
       exit();
   }   


    $servername="localhost";
    $username="root";
    $password="";
    $dbname="progetto";

    

    $conn=new mysqli($servername, $username, $password, $dbname);
    if($conn->connect_error)
    {
        die ("Connection failed " .$conn->connect_error);
    }

    if(isset($_GET["ricerca"]))
    {
        
        $ricerca=$_GET["ricerca"];
       
        $api_key="AIzaSyCPVsFOwCEKbbO_SXHR02nMVnwCTxUBkRc";
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL,"https://www.googleapis.com/books/v1/volumes?q=".$ricerca . '&key=' . $api_key);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            
        $result = curl_exec($curl);
        
        curl_close($curl);
        echo $result;
    }
    mysqli_close($conn);
?>