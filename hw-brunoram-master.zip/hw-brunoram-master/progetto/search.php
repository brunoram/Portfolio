<!DOCTYPE html>

<html>

<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="search.css" />
    <script src="search.js" defer="true"></script>
    <title>MyLibrary-Search</title>
    </head>

    <body>
        <?php
        
        session_start();
        
        if(!isset($_SESSION["user"]))
        {
            header("Location: http://localhost/progetto/login.php");
            exit();
        }   

       
        ?>
    <header> 
               <div id= "div_max_header">
                  <div id="div_header"> <h1 id="firsth1">MY LIBRARY</h1> 
                  <img id="img_cont" src="images/MyLibrary-logo-giglio.png"> <h1 id="secondh1">La tua libreria online</h1> 
                   
                 </div>
               </div>
            </header>
            <section id="blank">
              
            </section>  <div id="blue_title"><h1>Ricerca Libri</h1></div>
    <article>
                 <section id="men">
                 <ul class="menu">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="search.php">Ricerca</li>
                    
                    <li><a href="logout.php">Logout</a></li>
                </ul>
                </section>


                <section id="contenuto">
                  <div id="cont"><h2>  Inserisci titolo volume: </h2>
               
                    <form id="search_form">
                 <input type="search" name="ricerca" id="search_bar">
                <input type="submit" class="ricerca" name="submit" value="Inizia la ricerca">
        </form> </div>
                <div id="box-flex">
                        

                </div> 
                </section>
                <section id="right"> </section>
</article>
    <br>
    <br>
    <br>
    <footer>
       <p> Made by BR Corp. ©2019</p>
    </footer>
</body>

</html>