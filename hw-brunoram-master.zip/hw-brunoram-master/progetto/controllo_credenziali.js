


/*RIEMPIRE I CAMPI CON I DATI PRECEDENTEMENTE INSERITI
*
*
*
*
*
*
*

*
*
*
*/

function controllaUsername(){
    const form=document.querySelector("#sign-up");
    form.username.addEventListener('blur', usernameControl);
}

function usernameControl(){
    const form=document.querySelector("#sign-up");
    const user=form.username.value;
   
    fetch('http://localhost/progetto/controllo_username.php?us=' + user).then(responseUser).then(onText);
}

function responseUser(response){
    
   return response.text();
  
}

function onText(text) {
  
    if (text==0){
        document.querySelector("#us_control").style.display='block'; 
    }
    else document.querySelector("#us_control").style.display='none'; 
    
}


function controllaDatiInseriti(){
    document.querySelector("#sign-up").addEventListener('submit', controllaData);
}
controllaUsername();
controllaDatiInseriti();

function controllaData(event){
    
    const form=document.querySelector("#sign-up");
  
    if (form.email.value.indexOf("@") == -1)
    {document.querySelector("#at_control").style.display='block';
    event.preventDefault();
    }

    
    if (form.password.value!=form.psw_confirm.value){
    document.querySelector("#psw_control").style.display='block'; 
    event.preventDefault();
    }
   
   
    if (form.nome.value.length==0 ||
        form.cognome.value.length==0 ||
        form.tel.value.length==0 ||
        form.email.value==0  ||
        form.username.value.length==0 ||
        form.password.value.length==0 ||
        form.psw_confirm.value.length==0)
        {
        document.querySelector(".errore_compilazione_hidden").style.display='block'; 
        event.preventDefault();
        }
    else {
        onSubmitForm();
    }
}