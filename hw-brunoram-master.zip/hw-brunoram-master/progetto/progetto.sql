-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 12, 2019 alle 20:27
-- Versione del server: 10.1.36-MariaDB
-- Versione PHP: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `progetto`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `contenuto`
--

CREATE TABLE `contenuto` (
  `id_contenuto` bigint(20) NOT NULL,
  `id_raccolta` bigint(20) NOT NULL,
  `titolo` varchar(400) NOT NULL,
  `autore` text NOT NULL,
  `editore` text NOT NULL,
  `pagine` int(5) NOT NULL,
  `id_google` text NOT NULL,
  `url_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `contenuto`
--

INSERT INTO `contenuto` (`id_contenuto`, `id_raccolta`, `titolo`, `autore`, `editore`, `pagine`, `id_google`, `url_image`) VALUES
(13, 1, 'Le cose dell\'amore', 'Umberto Galimberti', 'Feltrinelli Editore', 176, 'LcbGCgAAQBAJ', 'http://books.google.com/books/content?id=LcbGCgAAQBAJ&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(13, 3, 'Le cose dell\'amore', 'Umberto Galimberti', 'Feltrinelli Editore', 176, 'LcbGCgAAQBAJ', 'http://books.google.com/books/content?id=LcbGCgAAQBAJ&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(14, 3, 'Amore. Come stare insieme tutta la vita', 'Valerio Albisetti', 'Paoline', 158, '7VjhZ_KffmoC', 'http://books.google.com/books/content?id=7VjhZ_KffmoC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(14, 4, 'Amore. Come stare insieme tutta la vita', 'Valerio Albisetti', 'Paoline', 158, '7VjhZ_KffmoC', 'http://books.google.com/books/content?id=7VjhZ_KffmoC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(15, 3, 'Psafone trattato d\'amore del Caliginoso Gelato il s. Melchiorre Zoppio, nel quale secondo i poeti, e filosofi, ethnici, e profani scrittori, platonici, & altri, si discorre sopra le principali considerationi occorrenti nella materia dell\'amore humano, ragioneuole, e ciuile', 'Melchiorre Zoppio', '', 632, 'ETxdZemdQucC', 'http://books.google.com/books/content?id=ETxdZemdQucC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(15, 5, 'Psafone trattato d\'amore del Caliginoso Gelato il s. Melchiorre Zoppio, nel quale secondo i poeti, e filosofi, ethnici, e profani scrittori, platonici, & altri, si discorre sopra le principali considerationi occorrenti nella materia dell\'amore humano, ragioneuole, e ciuile', 'Melchiorre Zoppio', '', 632, 'ETxdZemdQucC', 'http://books.google.com/books/content?id=ETxdZemdQucC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(17, 1, 'Il Vangelo secondo Harry Potter', 'Connie Neal', 'Gribaudi', 176, 'ayOd_Lu7m_MC', 'http://books.google.com/books/content?id=ayOd_Lu7m_MC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(18, 1, 'Intelligenza artificiale', 'Nils J. Nilsson', 'Apogeo Editore', 512, 'vLhaR8ekbfIC', 'http://books.google.com/books/content?id=vLhaR8ekbfIC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(19, 1, 'Natura umana, natura artificiale', 'AA. VV.', 'FrancoAngeli', 242, '4_Zc5JjSWeEC', 'http://books.google.com/books/content?id=4_Zc5JjSWeEC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(20, 1, 'Intelligenza artificiale. Un approccio moderno', 'Stuart J. Russell,Peter Norvig', 'Pearson Italia S.p.a.', 684, 'cNyndn1eI64C', 'http://books.google.com/books/content?id=cNyndn1eI64C&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(21, 1, 'Intelligenza artificiale, protezione dei dati personali e regolazione', 'Giuseppe D\'Acquisto,Maurizio Naldi,Raffaele Bifulco,Oreste Pollicino,Bassani Marco', 'G Giappichelli Editore', 432, 'h_JcDwAAQBAJ', 'http://books.google.com/books/content?id=h_JcDwAAQBAJ&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(22, 1, 'Invito all\'intelligenza artificiale', 'Luigia Carlucci Aiello,Marta Cialdea Mayer', 'FrancoAngeli', 160, 'xY9qCMFnpjYC', 'http://books.google.com/books/content?id=xY9qCMFnpjYC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(23, 1, 'La sfida della complessità', 'Gianluca Bocchi,Mauro Ceruti', 'Pearson Italia S.p.a.', 407, '2yvP-yTXdooC', 'http://books.google.com/books/content?id=2yvP-yTXdooC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(25, 1, 'L\'ordine della complessità', 'Alessandro Giuliani,Joseph P. Zbilut', 'Editoriale Jaca Book', 160, 'SUZF-8g4OXgC', 'http://books.google.com/books/content?id=SUZF-8g4OXgC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(26, 7, 'Il cielo. Istruzioni per l\'uso', 'Massimo Morroni', 'Edizioni Nuova Cultura', 196, 'If4YsrjbRmwC', 'http://books.google.com/books/content?id=If4YsrjbRmwC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(27, 7, 'Una stella marina in cielo', 'Alberto Albus Bustreo', 'nonno beppe editore', 49, 'RR1LDwAAQBAJ', 'http://books.google.com/books/content?id=RR1LDwAAQBAJ&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(28, 8, 'Il cielo', 'Aristoteles', '', 549, 'K_vpAAAAMAAJ', 'http://books.google.com/books/content?id=K_vpAAAAMAAJ&printsec=frontcover&img=1&zoom=5&source=gbs_api');

-- --------------------------------------------------------

--
-- Struttura della tabella `raccolta`
--

CREATE TABLE `raccolta` (
  `id_utente` bigint(20) NOT NULL,
  `id_raccolta` bigint(20) NOT NULL,
  `titolo` varchar(200) NOT NULL,
  `img_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `raccolta`
--

INSERT INTO `raccolta` (`id_utente`, `id_raccolta`, `titolo`, `img_url`) VALUES
(26, 1, 'Libro1', 'http://www.like-agency.it/media/k2/items/cache/d6086de322f98f66cc694f32ea284557_L.jpg'),
(34, 2, 'Libro2', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSl-SLdF1zHP2dP8n5XLhmWTaNmD-80uz99LNbe2Mj0LPcxyf_O'),
(26, 3, 'Aloha', 'https://st3.depositphotos.com/1201487/17635/v/1600/depositphotos_176353676-stock-illustration-aloha-hawaii-aloha-t-shirt.jpg'),
(26, 4, 'Macarena', 'https://i.ytimg.com/vi/vQytC8WMw6I/maxresdefault.jpg'),
(26, 5, 'f', 'http://books.google.com/books/content?id=ETxdZemdQucC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(26, 6, 'prova', 'http://books.google.com/books/content?id=lfSDbDsMnBYC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(118, 7, 'Raccolta1', 'http://books.google.com/books/content?id=If4YsrjbRmwC&printsec=frontcover&img=1&zoom=5&edge=curl&source=gbs_api'),
(118, 8, 'due', 'http://books.google.com/books/content?id=K_vpAAAAMAAJ&printsec=frontcover&img=1&zoom=5&source=gbs_api');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `Nome` varchar(50) NOT NULL,
  `Cognome` varchar(50) NOT NULL,
  `Email` varchar(253) NOT NULL,
  `Telefono` varchar(16) NOT NULL,
  `nome_utente` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `id_utente` bigint(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`Nome`, `Cognome`, `Email`, `Telefono`, `nome_utente`, `password`, `id_utente`) VALUES
('gdfhdf', 'dfhdh', 'gfhdhfghg@', '45754', '346dd', '12', 24),
('aaaaaaaa', 'aaaaa', 'aaaaaa@', 'ty546754', 'aa', 'aa', 26),
('aaaa', 'aaaa', 'aaaa@', 'fy5434', '43', 'a', 32),
('aaaaa', 'aaaa', 'aaaa@536', '43634', 'a', 'aa', 34),
('', '', '', '', '', '', 35),
('Prova', 'Prova', 'prova@prova', '326346', 'prova45', 'p1', 113),
('Ciao', 'Ciao', 'ciao@as', '234952', 'ciao', '1', 115),
('Javier', 'Zanetti', 'javier@zanetti', '12345', 'javier', 'a1', 118);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `contenuto`
--
ALTER TABLE `contenuto`
  ADD PRIMARY KEY (`id_contenuto`,`id_raccolta`),
  ADD KEY `new_raccid` (`id_raccolta`);

--
-- Indici per le tabelle `raccolta`
--
ALTER TABLE `raccolta`
  ADD PRIMARY KEY (`id_raccolta`,`id_utente`),
  ADD KEY `new_user` (`id_utente`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id_utente`),
  ADD UNIQUE KEY `Telefono` (`Telefono`),
  ADD UNIQUE KEY `email` (`Email`),
  ADD UNIQUE KEY `usernam` (`nome_utente`) USING BTREE;

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `contenuto`
--
ALTER TABLE `contenuto`
  MODIFY `id_contenuto` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT per la tabella `raccolta`
--
ALTER TABLE `raccolta`
  MODIFY `id_raccolta` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id_utente` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `contenuto`
--
ALTER TABLE `contenuto`
  ADD CONSTRAINT `contenuto_ibfk_1` FOREIGN KEY (`id_raccolta`) REFERENCES `raccolta` (`id_raccolta`) ON UPDATE CASCADE;

--
-- Limiti per la tabella `raccolta`
--
ALTER TABLE `raccolta`
  ADD CONSTRAINT `raccolta_ibfk_1` FOREIGN KEY (`id_utente`) REFERENCES `utenti` (`id_utente`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
