<?php
    $servername = "localhost";
    $us = "root";
    $pass = "";
    $dbname = "progetto";
    session_start();
    if (isset($_SESSION["user"])){
        header("Location: http://localhost/progetto/home.php");
        exit();
    }
     
    if (isset($_POST["user"]) && isset($_POST["psw"])&& $_POST["user"]!="" && $_POST["psw"]!="")
    {
        
        $conn = new mysqli($servername, $us, $pass, $dbname);
        if (mysqli_connect_errno()) 
        {
            printf("Connect failed: %s\n", mysqli_connect_error());
            exit();
        }

        $username=mysqli_real_escape_string($conn,$_POST["user"]);
        $password=mysqli_real_escape_string($conn,$_POST["psw"]);

        $confronta_credenziali = mysqli_query($conn, "SELECT nome_utente, password from utenti where nome_utente='$username' and password='$password'");
        $num=mysqli_num_rows($confronta_credenziali);
        
        if($num===0){
            $flag="1";
            echo ($flag);
            
        }
        else
        {
            $id_user=mysqli_query ($conn, "SELECT id_utente from utenti where nome_utente='$username'");
            $id=mysqli_fetch_row($id_user);
            $_SESSION["user"]= $id[0];  //setto l'id_utente come attributo della sessione.
            
            header("Location: http://localhost/progetto/home.php");
            exit();
        }
       mysqli_close($conn);
       mysqli_free_result($confronta_credenziali);
       
       
    }
    ?>