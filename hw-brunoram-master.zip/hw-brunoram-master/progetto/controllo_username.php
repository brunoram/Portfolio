 <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "progetto";
        
     
     
        if (isset($_GET["us"]))
        {
            
            $conn = new mysqli($servername, $username, $password, $dbname);
            if (mysqli_connect_errno()) {
                printf("Connect failed: %s\n", mysqli_connect_error());
                exit();
            }
            $value = mysqli_real_escape_string($conn, $_GET["us"]);
            
            
            $trova_user = mysqli_query($conn, "SELECT nome_utente from utenti where nome_utente='$value'");
            $num=mysqli_num_rows($trova_user);
            if($num===0){
                $flag=1;
                echo $flag;
                
            }
            else{
           $flag=0;
           echo $flag;
            
        }
       
        mysqli_close($conn);
        
        }
        
    ?>