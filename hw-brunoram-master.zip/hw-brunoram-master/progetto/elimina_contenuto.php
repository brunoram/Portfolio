<?php

session_start();

if(!isset($_SESSION["user"]))
{
    header("Location: http://localhost/progetto/login.php");
    exit();
}

    $servername="localhost";
    $username="root";
    $password="";
    $dbname="progetto";
   
    $user=$_SESSION["user"];
    $conn=new mysqli($servername, $username, $password, $dbname);
    if($conn->connect_error)
    {
         die ("Connection failed " .$conn->connect_error);
    }
    
    if(isset($_GET["idcont"]) && isset($_GET["idracc"]))
   {
    $id_cont=mysqli_real_escape_string($conn,$_GET["idcont"]);
    $id_racc=mysqli_real_escape_string($conn,$_GET["idracc"]);
   
    $delete=mysqli_query($conn, "DELETE from contenuto where id_contenuto='$id_cont' and id_raccolta='$id_racc'");

    
    mysqli_free_result($delete);

   }
   mysqli_close($conn);
?>