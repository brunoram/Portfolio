
function onLoadBox()
{
  const box =document.querySelector("#box-flex");
  window.addEventListener("load", fetch_mostraRaccolte);
}
onLoadBox();

function fetch_mostraRaccolte()
{
  fetch("http://localhost/progetto/mostra_raccolte.php").then(onResponse).then(onJSON);
}

function onResponse(response){
  
  return response.json();
}

function onJSON(json){
  const box_flex=document.querySelector("#box-flex");
  for(let element of json)
  {
  
  const div=document.createElement('div');
  div.classList.add("collection");

  const link=document.createElement('a');
  link.classList.add("links");
  link.href="collection.php?titolo="+element.titolo+"&id="+element.id_raccolta;
  
  const img=document.createElement('img');
  img.classList.add("image");
  img.src=element.img_url;
  
  

  p=document.createElement('p');
  var node = document.createTextNode(element.titolo);
  p.appendChild(node);
  div.appendChild(link);
  link.appendChild(img);
  link.appendChild(p);
  box_flex.appendChild(div);
  }
}