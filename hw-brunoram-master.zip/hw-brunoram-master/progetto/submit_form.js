

function onSubmitForm(){
    const form=document.querySelector("#sign-up");
    form.addEventListener('submit', inviaForm);
}

function inviaForm(){
    const form = new FormData(document.querySelector('#sign-up'));
   
    fetch('http://localhost/bruno/signup.php',{
        method: "POST",
        body: form
      })
}
