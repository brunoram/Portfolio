<!DOCTYPE html>

<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MyLibrary</title>
    <link rel="stylesheet" href="style-sign.css" />
    <script src="controllo_credenziali.js" defer="true"></script>
    <script src="submit_form.js"></script>
 <!--INSERIRE FONT GOOGLE-->
</head>

<body>
<?php
    session_start();
    if (isset($_SESSION["user"])){
        header("Location: http://localhost/progetto/home.php");
        exit();
    }

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "progetto";
       
    if (isset($_POST))
    {
        $conn = new mysqli($servername, $username, $password, $dbname);
        if (mysqli_connect_errno()) 
        {
            printf("Connect failed: %s\n", mysqli_connect_error());
            exit();
        }

        $nome=@mysqli_real_escape_string($conn,$_POST["nome"]);
        $cognome=@mysqli_real_escape_string($conn,$_POST["cognome"]);
        $email=@mysqli_real_escape_string($conn,$_POST["email"]);
        $tel=@mysqli_real_escape_string($conn,$_POST["tel"]);
        $username=@mysqli_real_escape_string($conn,$_POST["username"]);
        $password_=@mysqli_real_escape_string($conn,$_POST["password"]);

        

        if (mysqli_query($conn, "INSERT INTO utenti (Nome, Cognome, Email, Telefono, nome_utente,password) VALUES
         ('$nome', '$cognome', '$email', '$tel', '$username', '$password_')")===TRUE){
             $id_user=mysqli_query ($conn, "SELECT id_utente from utenti where nome_utente='$username'");
             $id=mysqli_fetch_row($id_user);
             $_SESSION["user"]= $id[0];
           header("Location: http://localhost/progetto/home.php");
           exit();
         }
         mysqli_close($conn);
    }
?>
    <header>
        <div id="bar">
       
        <div id= "div_max_header">
                  <div id="div_header"> <h1 id="firsth1">MY LIBRARY</h1> 
                  <img id="img_cont" src="images/MyLibrary-logo-giglio.png"> <h1 id="secondh1">La tua libreria online</h1> 
                   
                 </div>
               </div>
        </div>
    </header>
    <section id="blank">
              <h1 id="sign">Sign-up</h1>  
              </section>
    <article>
        
    <section id="blue_box">
       <div id="login"> 
            <button class="btn" name="reind_login" onclick="location.href='login.php'">Vai al login</button> 
</div>
    <div id="flex">
            
        </div>
        <p class='errore_compilazione_hidden'>Attenzione! Compilare tutti i campi.</p>
        <p id="us_control" class='errore_compilazione_hidden'>Username non disponibile.</p>
        <p id="at_control" class='errore_compilazione_hidden'>Attenzione! Campo email non valido.</p>
        <p id="psw_control" class='errore_compilazione_hidden'>Attenzione! Le password che hai inserito sono diverse.</p>
    <div id="main">
        <form id="sign-up" method='post' name='signup'>
        <p>
                <label>Nome: <input class="up" type="text" name="nome"></label>
</p>
<p>              <label>Cognome: <input class="up" type="text" name="cognome"></label>
</p>
<p>              <label>Email: <input class="up" type="text" name="email"></label> <!--esiste il type="email" ma non è stato utilizzato preferendo creare la funzione di validazione semplice per la @ in JS -->
</p>
<p>
                <label>Telefono: <input class="up" type="tel" name="tel"></label>
</p> <p>
                <label>Nome utente: <input class="up" type="text" name="username"></label>
</p> <p>
                <label>Password: <input class="up" type="password" name="password"></label>
</p> <p>
                <label id="confirm">Conferma Password: <input id="last" class="up" type="password" name="psw_confirm"></label>
</p> <p>
                
                <label>&nbsp;<input class="btn" type="submit" name="submit"></label>
</p>
        </form> </div>
</section>
    </article>
    <br>
    <br>
    <br>
    <footer>
       <p> Made by BR Corp. ©2019</p>
    </footer>

</body>
</html>