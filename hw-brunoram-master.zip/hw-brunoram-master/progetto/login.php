<!DOCTYPE html>

<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MyLibrary</title>
    <link rel="stylesheet" href="login.css" />
    <script src="login.js" defer="true"></script>
    <!--INSERIRE FONT GOOGLE-->
</head>

<body>
    <?php 
include '../progetto/confronta_credenziali.php';

?>

        <header>
            <div id="div_max_header">
                <div id="div_header">
                    <h1 id="firsth1">MY LIBRARY</h1>
                    <img id="img_cont" src="images/MyLibrary-logo-giglio.png">
                    <h1 id="secondh1">La tua libreria online</h1>

                </div>
            </div>
        </header>
        <section id="blank">
            <h1>BENVENUTO! <input type="button" class="accedi" value="Registrati" onclick="location.href='signup.php'"></h1>
              
        </section>
        <div id="blue_title">
            <h1>Login</h1>
            <form id="login" method="post">
                <span class="tex"> Username: </span>
                <input class="up" type="text" name="user">
                <br>
                <span class="tex"> Password: </span>
                <input class="up" type="password" name="psw">
                <br>
                <input type="checkbox" name="remember"> Ricordami
                <br>
                <input type="submit" class="accedi" value="Accedi">
            </form>
        </div>

        <footer>
            Made by BR Corp. ©2019
        </footer>

</body>

</html>