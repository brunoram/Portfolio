<!DOCTYPE html>

<html>

<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="home.css" />
    <script src="home.js" defer="true"></script>
    <script src="home_inserisci.js" defer="true"></script>
    <title>MyLibrary</title>
    </head>

    <body>
        <?php
           include "../progetto/inserisci_raccolta.php";
           

        ?>
            <header> 
            <div id= "div_max_header">
                  <div id="div_header"> <h1 id="firsth1">MY LIBRARY</h1> 
                  <img id="img_cont" src="images/MyLibrary-logo-giglio.png"> <h1 id="secondh1">La tua libreria online</h1> 
                   
                 </div>
            </header>
            <section id="blank">
              
            </section>  <div id="blue_title"><h1>Benvenuto in MyLibrary, la libreria online preferita!</h1></div>

            <article>
                 <section id="men">
                 <ul class="menu">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="search.php">Ricerca</li>
                    
                    <li><a href="logout.php">Logout</a></li>
                </ul>
                </section>


                <section id="contenuto">
                    
                    <h2>Ecco le tue raccolte: </h2>
               
                   
                <div id="box-flex">
                         
                </div> 
                <section id="crea_raccolta">
                    <h2>Crea nuova raccolta: </h2>
            <form id="new_raccolta">
                <label> Titolo raccolta  <input type="text" id="create_bar" name="titolo_raccolta"></label>
                <input type="submit" class="ricerca" name="invia" value="Invia">
        </form>
                </section>
                <section id="right"> </section>
</article>
    

            </section>

    <br>
    <br>
    <br>
    <footer>
       <p> Made by BR Corp. ©2019</p>
    </footer>
</body>

</html>