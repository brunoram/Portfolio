<!DOCTYPE html>

<html>

<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="collection.css" />
    <script src="collection.js" defer=true></script>
    <title>MyLibrary-Collection</title>
    </head>

    <body>

<?php
session_start();

if(!isset($_SESSION["user"])){
    header("Location: http://localhost/progetto/login.php");
    exit();
}   

 $servername="localhost";
 $username="root";
 $password="";
 $dbname="progetto";

 $user=$_SESSION["user"];
 $conn=new mysqli($servername, $username, $password, $dbname);
 if($conn->connect_error)
 {
      die ("Connection failed " .$conn->connect_error);
 }
 
 if(isset($_GET["titolo"]) && isset($_GET["id"]))
 {
    $title=$_GET["titolo"];
    $id=$_GET["id"];
    $_SESSION["id_raccolta"]=$id;
 }
    $utf = mysqli_query($conn, "set character set utf8");
    $check=mysqli_query($conn, "select * from raccolta where id_raccolta='$id' and id_utente='$user'");
    $num=mysqli_num_rows($check);
    if($num===0){
        $message = "Errore: stai tentando di accedere ad un elemento non di tua proprietà.";
        echo "<script type='text/javascript'>alert('$message');</script>";
        header("Location: http://localhost/progetto/home.php");
    }
mysqli_free_result($check);
mysqli_close($conn);
 ?>
 <header> 
               <div id= "div_max_header">
                  <div id="div_header"> <h1 id="firsth1">MY LIBRARY</h1> 
                  <img id="img_cont" src="images/MyLibrary-logo-giglio.png"> <h1 id="secondh1">La tua libreria online</h1> 
                   
                 </div>
               </div>
            </header>
            <section id="blank">
              
            </section>  
            <div id="blue_title"><h1>Raccolte</h1></div>
    <article>

    <section id="men">
                 <ul class="menu">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="search.php">Ricerca</li>
                    
                    <li><a href="logout.php">Logout</a></li>
                </ul>
                </section>


                <section id="contenuto">
                  <div id="cont"><h1 id="tit_racc">Raccolta: <?php echo $_GET["titolo"] ?> </h1>
                  <h2>Elenco Contenuti:</h2>
                   <h3>Clicca sul titolo o sull'immagine di un libro per visualizzare le sue informazioni.</h3>
                   <h3>Clicca su "Elimina libro" per eliminare il libro dalla raccolta.</h3>
                    </div>
                <div id="box-flex"> 
                  

                </div> 
                </section>
                <section id="right"> </section>
    </article>
    <br>
    <br>
    <br>
    <footer>
       <p> Made by BR Corp. ©2019</p>
    </footer>
</body>

</html>


