function creaRaccolta()
{
  const form=document.querySelector("#new_raccolta");
  form.addEventListener('submit', inserisci);
}

function inserisci()
{ 
 const form=document.querySelector("#new_raccolta");

    fetch('http://localhost/bruno/inserisci_raccolta.php'+form.titolo_raccolta.value);
}
//creaRaccolta();  
