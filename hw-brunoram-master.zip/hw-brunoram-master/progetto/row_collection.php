<?php

session_start();

if(!isset($_SESSION["user"]))
{
    header("Location: http://localhost/progetto/login.php");
    exit();
}

    $servername="localhost";
    $username="root";
    $password="";
    $dbname="progetto";
   
    $user=$_SESSION["user"];
    $conn=new mysqli($servername, $username, $password, $dbname);
    if($conn->connect_error)
    {
         die ("Connection failed " .$conn->connect_error);
    }
    
    if(isset($_SESSION["id_raccolta"]))
    {
        $id=$_SESSION["id_raccolta"];
        
    $utf = mysqli_query($conn, "set character set utf8");
    $contenuti=mysqli_query($conn, "select * from contenuto where id_raccolta='$id'");
    
    while($riga=mysqli_fetch_assoc($contenuti))
     {
        $vector[]=$riga;
        
      }

mysqli_free_result($contenuti);

echo json_encode($vector);    
    }
mysqli_close($conn);
?>