<?php

session_start();

if(!isset($_SESSION["user"]))
{
    header("Location: http://localhost/progetto/login.php");
    exit();
}   
 $servername="localhost";
 $username="root";
 $password="";
 $dbname="progetto";

 $user=$_SESSION["user"];

 $conn=new mysqli($servername, $username, $password, $dbname);
 if($conn->connect_error)
 {
      die ("Connection failed " .$conn->connect_error);
 }


 $vector= array();
 if(isset($_POST))
 {
    $utf = mysqli_query($conn, "set character set utf8");
    $titolo=mysqli_real_escape_string($conn,$_POST["titolo"]);
    $autore=mysqli_real_escape_string($conn,$_POST["autore"]);
    $editore=mysqli_real_escape_string($conn,$_POST["editore"]);
    $pagine=mysqli_real_escape_string($conn,$_POST["pagine"]);
    $tit_raccolte=mysqli_real_escape_string($conn,$_POST["titolo_racc"]);
    $url_image=mysqli_real_escape_string($conn,$_POST["url_img"]);
    $id_google=mysqli_real_escape_string($conn,$_POST["id_google"]);
    $id_raccolta=mysqli_real_escape_string($conn,$_POST["id_raccolta"]);

    $check_equal=mysqli_query($conn, "select distinct id_contenuto from contenuto where id_google='$id_google'");
    $num=mysqli_num_rows($check_equal);
if($num===1)
{
    $riga=mysqli_fetch_array($check_equal);
    $id_cont=$riga["id_contenuto"];
    $insert=mysqli_query($conn, "INSERT INTO contenuto (id_contenuto, id_raccolta, titolo, autore, editore, pagine, id_google, url_image) VALUES ('$id_cont','$id_raccolta', '$titolo', '$autore', '$editore', '$pagine', '$id_google', '$url_image')");
}
else 
{
    $insert=mysqli_query($conn, "INSERT INTO contenuto (id_raccolta, titolo, autore, editore, pagine, id_google, url_image) VALUES ('$id_raccolta', '$titolo', '$autore', '$editore', '$pagine', '$id_google', '$url_image')");
}


$default_img_url="https://as1.ftcdn.net/jpg/01/74/44/62/500_F_174446259_iYCcLsC7BKaIlSKb7hScY80hNQdMpZgN.jpg";
$default_img_raccolta=mysqli_query($conn, "UPDATE raccolta SET img_url = '$url_image' WHERE id_raccolta='$id_raccolta' and img_url='$default_img_url'");
$row=mysqli_fetch_array($default_img_raccolta);


mysqli_free_result($insert);
mysqli_free_result($default_img_raccolta);

 }
mysqli_close($conn);
?>