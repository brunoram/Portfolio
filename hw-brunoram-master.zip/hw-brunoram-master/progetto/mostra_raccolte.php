<?php
session_start();

if(!isset($_SESSION["user"])){
    header("Location: http://localhost/progetto/login.php");
    exit();
}   

 $servername="localhost";
 $username="root";
 $password="";
 $dbname="progetto";

 $user=$_SESSION["user"];
 
 $vector= array();
 

$conn=new mysqli($servername, $username, $password, $dbname);
 if($conn->connect_error)
 {
      die ("Connection failed " .$conn->connect_error);
 }

 $utf = mysqli_query($conn, "set character set utf8");

 $ris = mysqli_query($conn, "SELECT id_raccolta, titolo, img_url from raccolta  where id_utente='$user'");

 while($riga=mysqli_fetch_assoc($ris))
     {
        $vector[]=$riga;
        
      }

mysqli_free_result($ris);
mysqli_close($conn);
echo json_encode($vector);    
?>